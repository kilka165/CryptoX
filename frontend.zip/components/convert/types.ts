export interface Coin {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
}
